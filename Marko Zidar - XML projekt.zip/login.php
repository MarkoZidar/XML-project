<html>
	<head>
		<title>Web Stranice Poznatih</title>
	</head>

	<style>
		body{
			font-family: Arial, Helvetica, sans-serif;
			margin:50px 0;
			background:#f2f2f2;
		}
		#forma{
			width: 300px;
			margin: 10% auto 0;
			text-align: center;
			border-radius: 5px;
		}
		footer{
			text-align: center;
			position: fixed;
			bottom: 0;
			width:100%;
			height:50px;
			background:#404040;
			color:white;
		}
		.putin{
			padding:4px 4px;
			margin:3px 0;
			border-radius: 5px;
		}
		.button{
			font-family: Arial, Helvetica, sans-serif;
			background-color: #404040;
			border: none;
			color: white;
			padding: 7px 22px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			margin:10px 0;
			border-radius: 5px;
		}
		.button:hover{
			background-color: #b3b3b3;
			color: black;
		}
		.button:active {
		background-color: #cccccc;
		}
		img{
			border:5px solid #404040;
			vertical-align:middle;
			width:200px;
			margin:10px;
		}
		.red{
			color: red;
		}
	</style>

	<body>
		<div id="forma">

		<form action="" method="post">

			<input id="name" name="username" type="text" placeholder="Korisnički račun" class="putin"><br>

			<input id="password" name="password" type="password" placeholder="Lozinka" class="putin"><br>

			<input name="submit" type="submit" value=" Login " class="button">

		</form>

		<?php
			$username="";
			$password="";

			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				
				$ans=$_POST;

				if (empty($ans["username"]))  {
						echo "<p class='red'>Korisnički račun nije unesen.</p>";
					
						}
				else if (empty($ans["password"]))  {
						echo "<p class='red'>Lozinka nije unesena.</p>";
					
						}
				else {
					$username= $ans["username"];
					$password= $ans["password"];
				
					provjera($username,$password);
				}
			}


			function provjera($username, $password) {
				

				$xml=simplexml_load_file("korisnici.xml");
				
				
				foreach ($xml->korisnik as $usr) {
					$usrn = $usr->username;
					$usrp = $usr->password;
					$usrime = $usr->ime;
					$usrprezime = $usr->prezime;
					$usrweb = $usr->web;
					$usrimg = $usr->slika;
					if($usrn==$username){
						if($usrp == $password){
							echo "<img src='$usrimg'/><br>
							Dobrodošli nazad $usrime $usrprezime<br>
							<form action='$usrweb'>
								<input type='submit' value='Vaš Website' class='button'/>
							</form>";
							return;
							}
						else{
							echo "<p class='red'>Netocna lozinka</p>";
							return;
							}
						}
					}
					
				echo "<p class='red'>Korisnik ne postoji.</p>";
				return;
			}
		?>
		</div>

		<footer>
		<p>© 2021 - TVZ, Marko Zidar</p>
		</footer>

	</body>
</html>